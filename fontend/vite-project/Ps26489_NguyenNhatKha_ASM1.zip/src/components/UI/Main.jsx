import { Link } from "react-router-dom"
import { useState, useEffect } from 'react';
import axios from 'axios';

import LogoApple from '../../assets/img/apple.svg';
import a from '../../assets/img/circle-check-regular.svg';
import b from '../../assets/img/truck-solid.svg';
import c from '../../assets/img/shield-solid.svg';
import d from '../../assets/img/rotate-right-solid.svg';
import ListProduct from "./ListProduct";

export default function Main(){
     const [categories, setCate] = useState([]);

     useEffect(() => {
          const fetchCate = async () => {
               try {
                    const response = await axios.get('http://localhost:3000/categories');
                    setCate(response.data);
               } catch (error) {
                    console.error('Error fetching Categories:', error);
               }
          };

          fetchCate();
     }, []);


     return (
          <>
               <div>
                    <section className="slide-bar container-fluid">
                         <div
                              className="carousel slide"
                              data-bs-ride="carousel"
                              id="carouselExampleIndicators"
                         >
                              <div className="carousel-indicators">
                                   <button
                                        aria-current="true"
                                        aria-label="Slide 1"
                                        className="active"
                                        data-bs-slide-to="0"
                                        data-bs-target="#carouselExampleIndicators"
                                        type="button"
                                   />
                                   <button
                                        aria-label="Slide 2"
                                        data-bs-slide-to="1"
                                        data-bs-target="#carouselExampleIndicators"
                                        type="button"
                                   />
                                   <button
                                        aria-label="Slide 3"
                                        data-bs-slide-to="2"
                                        data-bs-target="#carouselExampleIndicators"
                                        type="button"
                                   />
                                   <button
                                        aria-label="Slide 4"
                                        data-bs-slide-to="3"
                                        data-bs-target="#carouselExampleIndicators"
                                        type="button"
                                   />
                              </div>
                              <div className="carousel-inner">
                                   <div className="carousel-item active">
                                        <img
                                             alt="..."
                                             className="d-block w-100"
                                             src="https://img.tgdd.vn/imgt/f_webp,fit_outside,quality_100,s_1920x533/https://cdn.tgdd.vn/2024/04/banner/dandau-2880-800--1--1920x533.png"
                                        />
                                   </div>
                                   <div className="carousel-item">
                                        <img
                                             alt="..."
                                             className="d-block w-100"
                                             src="https://img.tgdd.vn/imgt/f_webp,fit_outside,quality_100,s_1920x533/https://cdn.tgdd.vn/2024/04/banner/AW-SE-DD-2880-800-1920x533.png"
                                        />
                                   </div>
                                   <div className="carousel-item">
                                        <img
                                             alt="..."
                                             className="d-block w-100"
                                             src="https://img.tgdd.vn/imgt/f_webp,fit_outside,quality_100,s_1920x533/https://cdn.tgdd.vn/2024/06/banner/2880x800-1920x533.png"
                                        />
                                   </div>
                                   <div className="carousel-item">
                                        <img
                                             alt="..."
                                             className="d-block w-100"
                                             src="https://img.tgdd.vn/imgt/f_webp,fit_outside,quality_100,s_1920x533/https://cdn.tgdd.vn/2024/04/banner/iPad-9-2880-800-1920x533-2.png"
                                        />
                                   </div>
                              </div>
                              <button
                                   className="carousel-control-prev"
                                   data-bs-slide="prev"
                                   data-bs-target="#carouselExampleIndicators"
                                   type="button"
                              >
                                   <span
                                        aria-hidden="true"
                                        className="carousel-control-prev-icon"
                                   />
                                   <span className="visually-hidden">
                                        Previous
                                   </span>
                              </button>
                              <button
                                   className="carousel-control-next"
                                   data-bs-slide="next"
                                   data-bs-target="#carouselExampleIndicators"
                                   type="button"
                              >
                                   <span
                                        aria-hidden="true"
                                        className="carousel-control-next-icon"
                                   />
                                   <span className="visually-hidden">
                                        Next
                                   </span>
                              </button>
                         </div>
                       
                         <ul className="box-cate container d-flex justify-content-between" >
                         {categories.map((cate,index) => (
                              <li className="item-cate bg-dark " key={index}>
                                   <Link to={`listPrd/${cate._id}`}
                                        className="text-decoration-none "
                                        href=""
                                   >
                                        <img
                                             alt=""
                                             src={cate.image}
                                        />
                                        <span className="d-flex justify-content-center text-white">
                                             {cate.name}
                                        </span>
                                   </Link>
                              </li>
                              ))}
                         </ul>
                         <div className="box-slide container">
                              <a
                                   className="d-flex justify-content-center"
                                   href=""
                              >
                                   <img
                                        alt=""
                                        className="logo-apple"
                                        src={LogoApple}
                                   />
                                   <h2 className="desc-list">
                                        iPhone
                                   </h2>
                              </a>
                              <ListProduct categoryId='65ef17cecce6ab14801fd9b7' />
                         </div>
                         <div className="box-slide container">
                              <a
                                   className="d-flex justify-content-center"
                                   href=""
                              >
                                   <img
                                        alt=""
                                        className="logo-apple"
                                        src={LogoApple}
                                   />
                                   <h2 className="desc-list">
                                        Mac
                                   </h2>
                              </a>
                              <ListProduct categoryId='65ef17fccce6ab14801fd9bb' />
                         </div>
                         <div className="box-slide container">
                              <a
                                   className="d-flex justify-content-center"
                                   href=""
                              >
                                   <img
                                        alt=""
                                        className="logo-apple"
                                        src={LogoApple}
                                   />
                                   <h2 className="desc-list">
                                        iPad
                                   </h2>
                              </a>
                              <ListProduct categoryId='65ef1840cce6ab14801fd9bc' />

                         </div>
                         <div className="box-slide container">
                              <a
                                   className="d-flex justify-content-center"
                                   href=""
                              >
                                   <img
                                        alt=""
                                        className="logo-apple"
                                        src={LogoApple}
                                   />
                                   <h2 className="desc-list">
                                        WATCH
                                   </h2>
                              </a>
                              <ListProduct categoryId='65ef186ecce6ab14801fd9bd' />

                         </div>
                         <div className="box-slide container">
                              <a
                                   className="d-flex justify-content-center"
                                   href=""
                              >
                                   <h2 className="desc-list">
                                        Tai nghe, loa
                                   </h2>
                              </a>
                              <ListProduct categoryId='65f402eadb3f6e99065b15bf' />

                         </div>
                         <div className="box-slide container">
                              <a
                                   className="d-flex justify-content-center"
                                   href=""
                              >
                                   <img
                                        alt=""
                                        className="logo-apple"
                                        src={LogoApple}
                                   />
                                   <h2 className="desc-list">
                                        Phụ kiện
                                   </h2>
                              </a>
                              <ListProduct categoryId='65f4032edb3f6e99065b15c0' />

                         </div>
                    </section>
                    <section className="container-fluid justify-content-center bg-secondary ">
                         <div className="box-policy container d-flex justify-content-between">
                              <div className="policy">
                                   <img
                                        alt=""
                                        src={a}
                                   />
                                   <span>
                                        Mẫu mã đa dạng, chính hãng.
                                   </span>
                              </div>
                              <div className="policy">
                                   <img
                                        alt=""
                                        src={b}
                                   />
                                   <span>
                                        Giao hàng toàn quốc.
                                   </span>
                              </div>
                              <div className="policy">
                                   <img
                                        alt=""
                                        src={c}
                                   />
                                   <span>
                                        Bảo hành cam kết tới 12 tháng.
                                   </span>
                              </div>
                              <div className="policy">
                                   <img
                                        alt=""
                                        src={d}
                                   />
                                   <span>
                                        Đổi trả tại Thegioididong và DienmayXANH.
                                   </span>
                              </div>
                         </div>
                    </section>
               </div>
          </>
     )
}