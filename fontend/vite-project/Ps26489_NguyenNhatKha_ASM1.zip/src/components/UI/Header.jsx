import "../../assets/css/home.css";
import "../../assets/css/listProduct.css";
import "../../assets/css/home.css";
import Logo from '../../assets/img/logotopzone.jpg';
import search from '../../assets/img/search.svg';
import cart from '../../assets/img/shopping-cart.svg';
import { Link } from "react-router-dom";
export default function Header() {
     return (
          <>
               <header className="container-fluid">
                    <div className="container d-flex justify-content-between align-items-center">
                         <div>
                              <Link to='/'>
                                   <img
                                        alt=""
                                        className="img-logo"
                                        src={Logo}
                                   />
                              </Link>
                         </div>
                         <ul className="menu-header reset-list d-flex  ">
                              <li>
                                   <Link to='/listPrd/65ef17cecce6ab14801fd9b7'>iPhone</Link>
                              </li>
                              <li>
                                   <Link to='/listPrd/65ef17fccce6ab14801fd9bb'>Mac</Link>
                              </li>
                              <li>
                                   <Link to='/listPrd/65ef1840cce6ab14801fd9bc'>iPad</Link>
                              </li>
                              <li>
                                   <Link to='/listPrd/65ef186ecce6ab14801fd9bd'>Watch</Link>
                              </li>
                              <li>
                                   <Link to='/listPrd/65f402eadb3f6e99065b15bf'>Tai nghe, Loa</Link>
                              </li>
                              <li>
                                   <Link to='/listPrd/65f4032edb3f6e99065b15c0'>Phụ Kiện</Link>
                              </li>
                              <li>
                                   <Link to='/listPrd'>TekZone</Link>
                              </li>
                              <li>
                                   <Link to='/listPrd'>TopCare</Link>
                              </li>
                         </ul>
                         <div className="d-flex gap-3">
                              <div className="search">
                                   <img
                                        alt=""
                                        src={search}
                                   />
                              </div>
                              <div>
                                   <a href="">
                                        <img
                                             alt=""
                                             src={cart}
                                        />
                                   </a>
                              </div>
                         </div>
                    </div>
               </header>
          </>
     )
}