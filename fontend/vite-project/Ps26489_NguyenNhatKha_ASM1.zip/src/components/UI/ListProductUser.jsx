import LogoApple from '../../assets/img/apple.svg';
import { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
// import { Link } from "react-router-dom"
import axios from 'axios';
export default function ListProductUser() {
          const { categoryId } = useParams();
          const [products, setProducts] = useState([]);
          const [categoryName, setCategoryName] = useState('');

          useEffect(() => {
               const fetchProducts = async () => {
                    try {
                         const response = await axios.get(`http://localhost:3000/products/cate/${categoryId}`);
                         setProducts(response.data);
                    } catch (error) {
                         console.error('Error fetching products:', error);
                    }
               };

               fetchProducts();
          }, [categoryId]);

          useEffect(() => {
               const fetchCategoryName = async () => {
                 try {
                   const response = await axios.get(`http://localhost:3000/categories/${categoryId}`);
                   setCategoryName(response.data.name);
                 } catch (error) {
                   console.error('Error fetching category name:', error);
                 }
               };
           
               fetchCategoryName();
             }, [categoryId]);

     return (
          <>
               <div>
                    <section className="slide-bar container-fluid">
                         <div className="box-slide container">
                              <a
                                   className="d-flex justify-content-center"
                                   href=""
                              >
                                   <img
                                        alt=""
                                        className="logo-apple"
                                        src={LogoApple}
                                   />
                                   <h2 className="desc-list">
                                        {categoryName}
                                   </h2>
                              </a>
                              <div
                                   className="carousel slide slide-list"
                                   data-bs-ride="carousel"
                                   id="carouselExampleControls"
                              >
                                   <div className="carousel-inner">
                                        <div className="carousel-item active">
                                             <img
                                                  alt="..."
                                                  className="d-block w-100"
                                                  data-bs-interval="10000"
                                                  src="https://cdn.tgdd.vn/2024/07/banner/iPhone-11-2400-600-1920x480.png"
                                             />
                                        </div>
                                        <div className="carousel-item">
                                             <img
                                                  alt="..."
                                                  className="d-block w-100"
                                                  data-bs-interval="3000"
                                                  src="https://cdn.tgdd.vn/2024/07/banner/2400-600-1920x480.png"
                                             />
                                        </div>
                                   </div>
                                   <button
                                        className="carousel-control-prev"
                                        data-bs-slide="prev"
                                        data-bs-target="#carouselExampleControls"
                                        type="button"
                                   >
                                        <span
                                             aria-hidden="true"
                                             className="carousel-control-prev-icon"
                                        />
                                        <span className="visually-hidden">
                                             Previous
                                        </span>
                                   </button>
                                   <button
                                        className="carousel-control-next"
                                        data-bs-slide="next"
                                        data-bs-target="#carouselExampleControls"
                                        type="button"
                                   >
                                        <span
                                             aria-hidden="true"
                                             className="carousel-control-next-icon"
                                        />
                                        <span className="visually-hidden">
                                             Next
                                        </span>
                                   </button>
                              </div>
                              <div className="filter-cate container-fluid ">
                                   <a href="">
                                        Tất Cả
                                   </a>
                                   <a href="">{categoryName}</a>
                              </div>
                              <div className="box-item-product d-flex flex-wrap ">
                                   {products.map((product,index) => (
                                   <div className="item-product text-center bg-dark"  key= {index}>
                                             <Link to={`/productDetail/${product._id}`} >
                                                  <img
                                                       alt=""
                                                       src={product.product_image}
                                                  />
                                                  <h3 className="name">
                                                       {product.name}
                                                  </h3>
                                                  <span className="price">
                                                       {product.price_new}
                                                       <sup>
                                                            đ
                                                       </sup>
                                                       <strike>
                                                       {product.price_old}
                                                            <sup>
                                                                 đ
                                                            </sup>
                                                       </strike>
                                                       <small>
                                                            -15%
                                                       </small>
                                                  </span>
                                             </Link>
                                        

                                   </div>
                                   ))}
                              </div>
                         </div>
                    </section>
               </div>
          </>
     )
}