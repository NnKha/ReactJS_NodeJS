import PropTypes from 'prop-types';
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

// import { Link } from "react-router-dom"
import axios from 'axios';
export default function ListProduct({categoryId}) {
          const [products, setProducts] = useState([]);
          useEffect(() => {
               const fetchProducts = async () => {
                    try {
                         const response = await axios.get(`http://localhost:3000/products/cate/${categoryId}`);
                         setProducts(response.data);
                    } catch (error) {
                         console.error('Error fetching products:', error);
                    }
               };

               fetchProducts();
          }, [categoryId]);


     return (
          <>
               <div>
                    <section className="slide-bar container-fluid">
                         <div className="box-slide container">
                              <div className="box-item-product d-flex flex-wrap ">
                                   {products.map((product,index) => (
                                   <div className="item-product text-center bg-dark"  key= {index}>
                                             <Link to={`/productDetail/${product._id}`} >
                                                  <img
                                                       alt=""
                                                       src={product.product_image}
                                                  />
                                                  <h3 className="name">
                                                       {product.name}
                                                  </h3>
                                                  <span className="price">
                                                       {product.price_new}
                                                       <sup>
                                                            đ
                                                       </sup>
                                                       <strike>
                                                       {product.price_old}
                                                            <sup>
                                                                 đ
                                                            </sup>
                                                       </strike>
                                                       <small>
                                                            -15%
                                                       </small>
                                                  </span>
                                             </Link>
                                        

                                   </div>
                                   ))}
                              </div>
                         </div>
                    </section>
               </div>
          </>
     )
}
ListProduct.propTypes = {
     categoryId: PropTypes.string.isRequired,
   };