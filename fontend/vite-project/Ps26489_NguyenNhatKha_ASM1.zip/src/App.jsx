import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
// import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Header from './components/UI/Header';
import Main from './components/UI/Main';
import ListProductUser from './components/UI/ListProductUser';
import DetailProductUser from './components/UI/DetailProductUser';
import Footer from './components/UI/Footer';

function App() {
  return (
    <>
      <Router>
        <Header />
          <Routes>
            <Route path="/" element = { <Main />}/>
            <Route path="/listPrd/:categoryId" element = { <ListProductUser />}/>
            <Route path="/productDetail/:id" element = { <DetailProductUser />}/>
            {/* <Route path="/listPrd" element = { <ListProduct categoryId='65ef17cecce6ab14801fd9b7' />}/> */}
          </Routes>
        <Footer />
      </Router>
    </>
  )
}

export default App
